# aivivn-sentiment-svm

Submission for AIviVN demo contest https://www.aivivn.com/contests/1
